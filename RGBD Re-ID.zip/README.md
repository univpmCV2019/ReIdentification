# CVRe-Identification
Progetto modifica di Video Re-Identification per l'esame di Computer Vision 2019 all'Università Politecnica delle Marche.
Sono inclusi il report e la presentazione powerpoint.